<?php
require_once __DIR__ . '/../models/User.php';

class UsuarioController {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        // NO llamar session_start() aquí
    }

    public function crear() {
        $this->ensureAdmin();
        include __DIR__ . '/../views/usuarios/create.php';
    }

    public function guardar() {
        $this->ensureAdmin();

        $nic = $_POST['nic'] ?? '';
        $cedula = $_POST['cedula'] ?? '';
        $password = $_POST['password'] ?? '';
        $modulos = $_POST['modulos'] ?? '';
        $created_by = $_SESSION['user']['id'] ?? 0;

        $userModel = new User($this->pdo);
        $userModel->create($nic, $cedula, $password, $modulos, $created_by);

        header('Location: ?controller=usuario&action=list');
        exit;
    }

    public function list() {
        $this->ensureLogin();

        $userModel = new User($this->pdo);
        $currentUser = $_SESSION['user'];

        if ($currentUser['nic_name'] === 'admin') {
            $users = $userModel->findByCreator($currentUser['id']);
        } else {
            $users = [];
        }

        $path = __DIR__ . '/../views/usuarios/list.php';
        if (!file_exists($path)) die("Error: el archivo $path no existe");
        include $path;
    }

    private function ensureLogin() {
        if (!isset($_SESSION['user'])) {
            header('Location: ?controller=auth&action=login');
            exit;
        }
    }

    private function ensureAdmin() {
        $this->ensureLogin();
        if ($_SESSION['user']['nic_name'] !== 'admin') {
            die('Acceso denegado: solo administrador puede crear usuarios.');
        }
    }
}

?>
