<?php
require_once 'models/Product.php';
class ProductoController {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }
    public function crear() {
        $this->ensureLogin();
        include 'views/productos/create.php';
    }
    public function guardar() {
        $this->ensureLogin();
        $nombre = $_POST['nombre'] ?? '';
        $serial = $_POST['serial'] ?? '';
        $created_by = $_SESSION['user']['id'];
        $p = new Product($this->pdo);
        $p->create($nombre, $serial, $created_by);
        header('Location: ?controller=producto&action=list');
    }
    public function list() {
        $this->ensureLogin();
        $p = new Product($this->pdo);
        // Solo listar productos creados por el usuario en sesión
        $products = $p->findByCreator($_SESSION['user']['id']);
        include 'views/productos/list.php';
    }
    private function ensureLogin() {
        if (!isset($_SESSION['user'])) {
            header('Location: ?controller=auth&action=login');
            exit;
        }
    }
}
?>
