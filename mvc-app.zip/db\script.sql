-- SQL script para crear la base de datos y tablas
CREATE DATABASE IF NOT EXISTS mvc_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mvc_app;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nic_name VARCHAR(100) NOT NULL,
  cedula VARCHAR(50),
  password VARCHAR(255) NOT NULL,
  modulos TEXT,
  created_by INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  serial VARCHAR(150) NOT NULL,
  created_by INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Pre-cargar el administrador (creado por sistema -> created_by = 0)
INSERT INTO users (nic_name, cedula, password, modulos, created_by) VALUES
('admin', '000', '12345678', 'ALL', 0);
