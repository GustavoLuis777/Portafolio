<!doctype html>
<html><head><meta charset="utf-8"><title>Lista Productos</title>
<link rel="stylesheet" href="public/style.css">
</head><body>
<div class="container">
<h2>Productos creados por el usuario en sesión</h2>
<p>Sesión: <?=htmlspecialchars($_SESSION['user']['nic_name'])?> | <a href="?controller=auth&action=logout">Salir</a></p>
<p><a href="?controller=producto&action=crear">Crear producto</a></p>
<table>
<tr><th>ID</th><th>Nombre</th><th>Serial</th></tr>
<?php foreach($products as $p): ?>
<tr>
    <td><?=htmlspecialchars($p['id'])?></td>
    <td><?=htmlspecialchars($p['nombre'])?></td>
    <td><?=htmlspecialchars($p['serial'])?></td>
</tr>
<?php endforeach; ?>
</table>
<p><a href="?controller=usuario&action=listar">Usuarios</a></p>
</div></body></html>
