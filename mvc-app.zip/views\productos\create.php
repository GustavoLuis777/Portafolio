<!doctype html>
<html><head><meta charset="utf-8"><title>Crear Producto</title>
<link rel="stylesheet" href="public/style.css">
</head><body>
<div class="container">
<h2>Crear Producto</h2>
<form method="POST" action="?controller=producto&action=guardar">
    <label>Nombre:</label><input name="nombre" required>
    <label>Serial:</label><input name="serial" required>
    <button type="submit">Guardar</button>
</form>
<p><a href="?controller=producto&action=listar">Volver</a></p>
</div></body></html>
