<?php
class User {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }
    public function create($nic, $cedula, $password, $modulos, $created_by) {
        $stmt = $this->pdo->prepare('INSERT INTO users (nic_name, cedula, password, modulos, created_by) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$nic, $cedula, $password, $modulos, $created_by]);
    }
    public function findByNic($nic) {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE nic_name = ? LIMIT 1');
        $stmt->execute([$nic]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function findByCreator($creator_id) {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE created_by = ?');
        $stmt->execute([$creator_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
