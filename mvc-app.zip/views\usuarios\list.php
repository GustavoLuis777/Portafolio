<!doctype html>
<html><head><meta charset="utf-8"><title>Lista Usuarios</title>
<link rel="stylesheet" href="public/style.css">
</head><body>
<div class="container">
<h2>Usuarios creados por el administrador en sesión</h2>
<?php if (isset($_SESSION['user'])): ?>
    <p>Sesión: <?=htmlspecialchars($_SESSION['user']['nic_name'])?> | <a href="?controller=auth&action=logout">Salir</a></p>
<?php endif; ?>
<?php if ($_SESSION['user']['nic_name'] === 'admin'): ?>
    <p><a href="?controller=usuario&action=crear">Crear usuario</a></p>
<?php endif; ?>
<table>
<tr><th>ID</th><th>Nic</th><th>Cedula</th><th>Modulos</th></tr>
<?php foreach($users as $u): ?>
<tr>
    <td><?=htmlspecialchars($u['id'])?></td>
    <td><?=htmlspecialchars($u['nic_name'])?></td>
    <td><?=htmlspecialchars($u['cedula'])?></td>
    <td><?=htmlspecialchars($u['modulos'])?></td>
</tr>
<?php endforeach; ?>
</table>
<p><a href="?controller=producto&action=list">Productos</a></p>
</div></body></html>
