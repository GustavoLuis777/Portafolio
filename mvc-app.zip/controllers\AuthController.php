<?php
require_once 'models/User.php';
class AuthController {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }
    public function showLogin() {
        include 'views/login.php';
    }
    public function login() {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $userModel = new User($this->pdo);
        $user = $userModel->findByNic($username);
        if ($user && $user['password'] === $password) {
            $_SESSION['user'] = $user;
            header('Location: ?controller=usuario&action=listar');
        } else {
            $error = 'Credenciales inválidas';
            include 'views/login.php';
        }
    }
    public function logout() {
        session_destroy();
        header('Location: ?controller=auth&action=login');
    }
}
?>
