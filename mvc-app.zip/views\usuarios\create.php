<!doctype html>
<html><head><meta charset="utf-8"><title>Crear Usuario</title>
<link rel="stylesheet" href="public/style.css">
</head><body>
<div class="container">
<h2>Crear Usuario (solo admin)</h2>
<form method="POST" action="?controller=usuario&action=guardar">
    <label>Nic:</label><input name="nic" required>
    <label>Cedula:</label><input name="cedula" required>
    <label>Password:</label><input name="password" required>
    <label>Modulos (texto):</label><input name="modulos">
    <button type="submit">Guardar</button>
</form>
<p><a href="?controller=usuario&action=list">Volver</a></p>
</div></body></html>
