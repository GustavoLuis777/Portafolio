<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<style>
    body { 
        font-family: Arial, sans-serif; 
        background: #f5f5f5; 
    }
    .container { 
        max-width: 400px; 
        margin: 80px auto; 
        background: #fff; 
        padding: 20px; 
        border-radius: 8px; 
        box-shadow: 0 2px 6px rgba(0,0,0,0.1); 
    }
    h2 { 
        text-align: center; 
        margin-bottom: 20px; 
    }
    label { 
        display: block; 
        margin-top: 10px; 
        font-weight: bold; 
    }
    input { 
        display: block; 
        margin-bottom: 15px; 
        padding: 8px; 
        width: 100%; 
        box-sizing: border-box; 
        border: 1px solid #ccc; 
        border-radius: 4px; 
    }
    button { 
        padding: 10px 16px; 
        border: none; 
        border-radius: 6px; 
        cursor: pointer; 
        width: 100%; 
        background-color: #4CAF50; 
        color: white; 
        font-size: 16px; 
    }
    button:hover { 
        background-color: #45a049; 
    }
    .error { 
        color: red; 
        text-align: center; 
        margin-bottom: 15px; 
    }
</style>
</head>
<body>
<div class="container">
<h2>Login</h2>
<?php if (!empty($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
<form method="POST" action="?controller=auth&action=login">
    <label>Usuario (nic):</label>
    <input name="username" required>
    <label>Password:</label>
    <input name="password" type="password" required>
    <button type="submit">Entrar</button>
</form>
</div>
</body>
</html>
