<?php
session_start();
require_once 'config/db.php';
require_once 'controllers/AuthController.php';
require_once 'controllers/UsuarioController.php';
require_once 'controllers/ProductoController.php';

$action = $_GET['action'] ?? 'home';
$controller = $_GET['controller'] ?? 'auth';

// Simple router
if ($controller == 'auth') {
    $c = new AuthController($pdo);
    if ($action == 'login') $c->login();
    elseif ($action == 'logout') $c->logout();
    else $c->showLogin();
} elseif ($controller == 'usuario') {
    $c = new UsuarioController($pdo);
    if ($action == 'crear') $c->crear();
    elseif ($action == 'guardar') $c->guardar();
    elseif ($action == 'list') $c->list();
    else $c->list();
} elseif ($controller == 'producto') {
    $c = new ProductoController($pdo);
    if ($action == 'crear') $c->crear();
    elseif ($action == 'guardar') $c->guardar();
    elseif ($action == 'list') $c->list();
    else $c->listar();
} else {
    echo '<a href="?controller=auth&action=login">Login</a>';
}
?>
