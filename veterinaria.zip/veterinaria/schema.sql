CREATE TABLE IF NOT EXISTS administradores (
    cedula TEXT PRIMARY KEY,
    primer_nombre TEXT NOT NULL,
    segundo_nombre TEXT,
    primer_apellido TEXT NOT NULL,
    segundo_apellido TEXT,
    mail TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_by TEXT
);