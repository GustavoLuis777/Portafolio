from flask import Flask, render_template, request, redirect, session, url_for, g
import sqlite3, bcrypt, os
 
app = Flask(__name__)
app.secret_key = 'veterinariaV1_secret_key'
DATABASE = 'database.db'
 
# ------------------------------------------
# Conexión a la base de datos
# ------------------------------------------
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db
 
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()
 
# ------------------------------------------
# Crear tablas y admin inicial
# ------------------------------------------
def init_db():
    with app.app_context():
        db = get_db()
        # Crear tabla administradores si no existe
        db.execute("""
        CREATE TABLE IF NOT EXISTS administradores (
            cedula TEXT PRIMARY KEY,
            primer_nombre TEXT NOT NULL,
            segundo_nombre TEXT,
            primer_apellido TEXT NOT NULL,
            segundo_apellido TEXT,
            mail TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_by TEXT
        );
        """)
 
        # Crear administrador inicial
        admin = db.execute("SELECT * FROM administradores WHERE mail=?", ('admin@admin.com',)).fetchone()
        if not admin:
            hashed = bcrypt.hashpw("12345678".encode('utf-8'), bcrypt.gensalt())
            db.execute("""
                INSERT INTO administradores 
                (cedula, primer_nombre, primer_apellido, mail, password, created_by)
                VALUES (?, ?, ?, ?, ?, ?)
            """, ('00000000', 'Admin', 'Principal', 'admin@admin.com', hashed, 'admin@admin.com'))
            db.commit()
 
# ------------------------------------------
# Rutas
# ------------------------------------------
@app.route('/')
def index():
    if 'user' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('home'))
 
# --- LOGIN ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        mail = request.form['mail']
        password = request.form['password']
        db = get_db()
        user = db.execute("SELECT * FROM administradores WHERE mail=?", (mail,)).fetchone()
 
        if user and bcrypt.checkpw(password.encode('utf-8'), user['password']):
            session['user'] = dict(user)
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Credenciales incorrectas")
 
    return render_template('login.html')
 
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))
 
# --- HOME (LISTADO DE ADMINISTRADORES) ---
@app.route('/home')
def home():
    if 'user' not in session:
        return redirect(url_for('login'))
 
    db = get_db()
    admins = db.execute("SELECT * FROM administradores WHERE created_by=?", (session['user']['mail'],)).fetchall()
    return render_template('home.html', admins=admins, user=session['user'])
 
# --- CREAR ADMINISTRADOR ---
@app.route('/crear', methods=['GET', 'POST'])
def crear_admin():
    if 'user' not in session:
        return redirect(url_for('login'))
 
    if request.method == 'POST':
        data = request.form
        hashed = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
        db = get_db()
        try:
            db.execute("""
                INSERT INTO administradores 
                (cedula, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, mail, password, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                data['cedula'],
                data['primer_nombre'],
                data.get('segundo_nombre', ''),
                data['primer_apellido'],
                data.get('segundo_apellido', ''),
                data['mail'],
                hashed,
                session['user']['mail']
            ))
            db.commit()
            return redirect(url_for('home'))
        except sqlite3.IntegrityError:
            return render_template('crear_admin.html', error="Cédula o correo ya existen.")
 
    return render_template('crear_admin.html')
 
# --- EDITAR ADMINISTRADOR ---
@app.route('/editar', methods=['GET', 'POST'])
def editar_admin():
    if 'user' not in session:
        return redirect(url_for('login'))
 
    db = get_db()
    if request.method == 'POST':
        cedula = request.form['cedula']
        admin = db.execute("SELECT * FROM administradores WHERE cedula=?", (cedula,)).fetchone()
        if admin:
            return render_template('editar_admin.html', admin=admin)
        else:
            return render_template('editar_admin.html', error="Administrador no encontrado")
 
    return render_template('editar_admin.html')
 
@app.route('/guardar_edicion', methods=['POST'])
def guardar_edicion():
    if 'user' not in session:
        return redirect(url_for('login'))
 
    data = request.form
    db = get_db()
    db.execute("""
        UPDATE administradores
        SET primer_nombre=?, segundo_nombre=?, primer_apellido=?, segundo_apellido=?, mail=?, password=?
        WHERE cedula=?
    """, (
        data['primer_nombre'],
        data.get('segundo_nombre', ''),
        data['primer_apellido'],
        data.get('segundo_apellido', ''),
        data['mail'],
        bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt()),
        data['cedula']
    ))
    db.commit()
    return redirect(url_for('home'))
 
# ------------------------------------------
# MAIN
# ------------------------------------------
if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    else:
        # Si el archivo existe, aseguramos que tenga la tabla
        with app.app_context():
            db = get_db()
            db.execute("""
            CREATE TABLE IF NOT EXISTS administradores (
                cedula TEXT PRIMARY KEY,
                primer_nombre TEXT NOT NULL,
                segundo_nombre TEXT,
                primer_apellido TEXT NOT NULL,
                segundo_apellido TEXT,
                mail TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                created_by TEXT
            );
            """)
            db.commit()
    app.run(debug=True)
